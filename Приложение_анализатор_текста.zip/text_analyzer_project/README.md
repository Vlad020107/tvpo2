# Анализатор текста: практическая работа № 2

Python 3.10+; pytest и coverage устанавливаются локально: `python -m pip install -r requirements.txt`.

В каталоге проекта:

- `python -m pytest -q test_initial.py test_improved.py` — итоговые тесты.
- `python -m coverage run -m pytest -q test_initial.py test_improved.py` и `python -m coverage report -m text_analyzer.py` — покрытие.
- `python mutation_check.py` — целевые мутации до/после улучшения тестов.

`text_analyzer_buggy.py` сохраняет первоначальный дефект: `len(text.split(" "))`. Чтобы воспроизвести его без правки тестов, используйте `python reproduce_bug.py`.

Мутационный сценарий реализован самостоятельно: временные копии модуля меняются по шести точно заданным правилам, затем каждый вариант отдельно проверяется pytest. Это не утверждение об исчерпывающем мутационном покрытии. Исходный модуль не изменяется.
